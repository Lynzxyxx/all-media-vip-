// Vercel Serverless Function
// Endpoint: /api/config
// Mengambil konfigurasi Firebase dari Environment Variables di Vercel,
// lalu mengirimkannya ke frontend sebagai JSON. Ini supaya key Firebase
// tidak perlu di-hardcode langsung di file index.html.

export default function handler(req, res) {
  const firebaseConfig = {
    apiKey: process.env.FIREBASE_API_KEY || "",
    authDomain: process.env.FIREBASE_AUTH_DOMAIN || "",
    projectId: process.env.FIREBASE_PROJECT_ID || "",
    storageBucket: process.env.FIREBASE_STORAGE_BUCKET || "",
    messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID || "",
    appId: process.env.FIREBASE_APP_ID || ""
  };

  res.setHeader('Cache-Control', 'no-store');
  res.status(200).json(firebaseConfig);
}
